import React from 'react'
import './header.css'

const Header = () => {
  return (
    <div className="header">
        <div className="header-contents">
            <h2>Order your <br />
            favorite  food here</h2>
            <p>bla bla bla bla bbbbalalalalalal balbalalalalalalala blabalabalbalbalbabal </p>
            <button>View Menu</button>
        </div>
    </div>
  )
}

export default Header